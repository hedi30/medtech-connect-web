import React, { useState } from "react";
import {
  FaRegComment,
  FaUser,
  FaStar,
  FaCheckCircle,
  FaExclamationTriangle,
  FaTrash,
  FaThumbsUp,
} from "react-icons/fa";

const ManagePostsPage = () => {
  const [posts, setPosts] = useState([
    {
      id: 1,
      user: "Alice",
      isAlumni: true,
      status: "Pending",
      likes: 15,
      content: "Excited to share my new research paper on AI ethics!",
      comments: [
        {
          id: 101,
          user: "John",
          text: "This sounds interesting!",
          status: "Pending",
        },
        {
          id: 102,
          user: "Emma",
          text: "I disagree with some of your points.",
          status: "Pending",
        },
      ],
    },
    {
      id: 2,
      user: "Bob",
      isAlumni: false,
      status: "Flagged",
      likes: 8,
      content: "Join us for the upcoming hackathon next week!",
      comments: [
        {
          id: 103,
          user: "Liam",
          text: "Looking forward to it!",
          status: "Pending",
        },
        {
          id: 104,
          user: "Sophia",
          text: "Where can I register?",
          status: "Pending",
        },
      ],
    },
  ]);

  const [expandedPost, setExpandedPost] = useState(null);

  const toggleComments = (postId) => {
    setExpandedPost(expandedPost === postId ? null : postId);
  };

  const updatePostStatus = (postId, newStatus) => {
    setPosts(
      posts.map((post) =>
        post.id === postId ? { ...post, status: newStatus } : post
      )
    );
  };

  const deletePost = (postId) => {
    if (window.confirm("Are you sure you want to delete this post?")) {
      setPosts(posts.filter((post) => post.id !== postId));
    }
  };

  const updateCommentStatus = (postId, commentId) => {
    setPosts(
      posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              comments: post.comments.map((comment) =>
                comment.id === commentId
                  ? { ...comment, status: "Approved" }
                  : comment
              ),
            }
          : post
      )
    );
  };

  const deleteComment = (postId, commentId) => {
    if (window.confirm("Are you sure you want to delete this comment?")) {
      setPosts(
        posts.map((post) =>
          post.id === postId
            ? {
                ...post,
                comments: post.comments.filter(
                  (comment) => comment.id !== commentId
                ),
              }
            : post
        )
      );
    }
  };

  return (
    <div className="bg-gray-900 text-white p-6 min-h-screen">
      <h1 className="text-3xl font-bold text-indigo-400">
        🛠 Manage Posts & Comments
      </h1>

      {/* Posts List */}
      <div className="space-y-6 mt-6">
        {posts.map((post) => (
          <div
            key={post.id}
            className="p-6 bg-gray-800 rounded-lg shadow-lg hover:shadow-xl transition-all"
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <FaUser className="text-white text-xl" />
                <h2 className="text-lg font-semibold">{post.user}</h2>
                {post.isAlumni && (
                  <FaStar className="text-yellow-500" title="Alumni" />
                )}
              </div>
              <span
                className={`px-3 py-1 rounded-full text-sm font-bold ${
                  post.status === "Approved"
                    ? "bg-green-500 text-white"
                    : post.status === "Flagged"
                    ? "bg-red-500 text-white"
                    : "bg-yellow-500 text-white"
                }`}
              >
                {post.status}
              </span>
            </div>

            <p className="mt-2 text-gray-300">{post.content}</p>

            {/* Like & Comment Count */}
            <div className="mt-3 flex items-center gap-4 text-gray-400">
              <div className="flex items-center gap-2">
                <FaThumbsUp /> <span>{post.likes}</span>
              </div>
              <div
                className="flex items-center gap-2 cursor-pointer hover:text-indigo-400 transition"
                onClick={() => toggleComments(post.id)}
              >
                <FaRegComment /> <span>{post.comments.length}</span>
              </div>
            </div>

            {/* Approve, Flag, Remove Post */}
            <div className="mt-3 flex justify-end gap-3">
              <button
                onClick={() => updatePostStatus(post.id, "Approved")}
                className="px-3 py-1 bg-green-500 rounded hover:bg-green-600 transition flex items-center gap-1"
              >
                <FaCheckCircle /> Approve
              </button>
              <button
                onClick={() => updatePostStatus(post.id, "Flagged")}
                className="px-3 py-1 bg-red-500 rounded hover:bg-red-600 transition flex items-center gap-1"
              >
                <FaExclamationTriangle /> Flag
              </button>
              <button
                onClick={() => deletePost(post.id)}
                className="px-3 py-1 bg-gray-600 rounded hover:bg-gray-700 transition flex items-center gap-1"
              >
                <FaTrash /> Remove
              </button>
            </div>

            {/* Comments Section */}
            {expandedPost === post.id && (
              <div className="mt-4 border-t border-gray-700 pt-3">
                <h5 className="font-medium text-white">Comments</h5>
                <ul className="mt-2 space-y-2">
                  {post.comments.map((comment) => (
                    <li
                      key={comment.id}
                      className={`flex justify-between items-center text-sm text-slate-400 p-3 rounded ${
                        comment.status === "Approved"
                          ? "bg-green-700 text-white"
                          : "bg-gray-700"
                      }`}
                    >
                      <span>
                        <strong className="text-white">{comment.user}:</strong>{" "}
                        {comment.text}
                      </span>
                      <div className="flex gap-2">
                        {comment.status !== "Approved" && (
                          <button
                            className="text-green-400 hover:text-green-500 cursor-pointer flex items-center gap-1"
                            onClick={() =>
                              updateCommentStatus(post.id, comment.id)
                            }
                          >
                            <FaCheckCircle />
                          </button>
                        )}
                        <FaTrash
                          className="text-red-400 hover:text-red-500 cursor-pointer"
                          onClick={() => deleteComment(post.id, comment.id)}
                        />
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ManagePostsPage;
