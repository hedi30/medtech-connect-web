import React from "react";
import ManagePosts from "../PostsComponents/ManagePosts";

const ManagePostsPage = () => {
  return <ManagePosts />;
};

export default ManagePostsPage;
