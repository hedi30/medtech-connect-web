import React, { useState, useEffect } from "react";
import { Box, Paper, InputBase, IconButton, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Button } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { styled, alpha } from "@mui/material/styles";
import SearchIcon from "@mui/icons-material/Search";
import DeleteRoundedIcon from "@mui/icons-material/DeleteRounded";
import { useNavigate } from "react-router-dom";
import userData from "../../../Data/users.json"; // Corrected path
 // Import the JSON data

// Search Bar Styling (Same as Group Chat)
const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.black, 0.05),
  "&:hover": { backgroundColor: alpha(theme.palette.common.black, 0.1) },
  margin: "auto",
  width: "100%",
  maxWidth: 400,
  display: "flex",
  alignItems: "center",
  padding: theme.spacing(0.5, 1),
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: theme.palette.text.secondary,
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  marginLeft: theme.spacing(1),
  flex: 1,
}));

const UserProfileList = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [open, setOpen] = useState(false); // For dialog
  const [selectedId, setSelectedId] = useState(null); // Track the profile to delete
  const [rows, setRows] = useState(userData); // Set initial rows with the imported data

  // Apply filtering logic
  const filteredRows = rows.filter(
    (row) =>
      row.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      row.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      row.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
      row.graduationYear.toString().includes(searchQuery)
  );

  // Handle row click for navigation
  const handleRowClick = (param) => {
    navigate(`/admin/profiles/${param.row.id}`);
  };

  // Open the delete dialog
  const handleClickOpen = (id) => {
    setSelectedId(id);
    setOpen(true);
  };

  // Close the delete dialog
  const handleClose = () => {
    setOpen(false);
    setSelectedId(null);
  };

  // Confirm delete action
  const handleConfirmDelete = () => {
    // Filter out the profile to be deleted
    setRows((prevRows) => prevRows.filter((row) => row.id !== selectedId));
    handleClose();
  };

  // Columns for the table
  const columns = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "name", headerName: "Name", width: 200 },
    { field: "role", headerName: "Role", width: 150 },
    { field: "specialty", headerName: "Specialty", width: 180 },
    { field: "graduationYear", headerName: "Graduation Year", width: 180 },
    {
      field: "actions",
      headerName: "Actions",
      width: 120,
      renderCell: (params) => (
        <Box display="flex" gap={1}>
          <IconButton
            onClick={(event) => {
              event.stopPropagation(); // Prevent row click when deleting
              handleClickOpen(params.row.id);
            }}
          >
            <DeleteRoundedIcon style={{ color: "black" }} />
          </IconButton>
        </Box>
      ),
    },
  ];

  return (
    <Box>
      {/* Search Bar */}
      <Box sx={{ my: 2, display: "flex", justifyContent: "center" }}>
        <Search>
          <SearchIconWrapper>
            <SearchIcon />
          </SearchIconWrapper>
          <StyledInputBase
            placeholder="Search User Profiles…"
            inputProps={{ "aria-label": "search" }}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </Search>
      </Box>

      {/* Table */}
      <Paper sx={{ height: 400, width: "100%" }}>
        <DataGrid
          rows={filteredRows}
          columns={columns}
          pageSizeOptions={[5, 10]}
          onRowClick={handleRowClick} // Trigger navigation on row click
        />
      </Paper>

      {/* Delete Confirmation Dialog */}
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{"Are you sure you want to delete this profile?"}</DialogTitle>
        <DialogContent>
          <DialogContentText>This action cannot be undone.</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">Cancel</Button>
          <Button onClick={handleConfirmDelete} color="primary">Confirm</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default UserProfileList;
